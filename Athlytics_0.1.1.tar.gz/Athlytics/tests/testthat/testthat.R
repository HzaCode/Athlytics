library(testthat)
library(Athlytics)

test_check("Athlytics", filter = "^(test-acwr|test-ef)") 