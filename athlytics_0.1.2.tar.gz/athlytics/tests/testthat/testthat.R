library(testthat)
library(athlytics)

# test_check("athlytics", filter = "^(test-acwr|test-ef)") 